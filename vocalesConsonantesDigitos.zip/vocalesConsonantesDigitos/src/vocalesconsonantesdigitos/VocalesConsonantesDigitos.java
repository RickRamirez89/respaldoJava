/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vocalesconsonantesdigitos;

import java.util.Scanner;

/**
 *
 * @author rdominguez
 */
public class VocalesConsonantesDigitos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        String palabra;
        int consonante=0, vocal=0,totalconsonante,digitos=0;
        System.out.println("Ingresa Palabra: ");
        palabra=entrada.nextLine();
        
        
        for(int i=0; i<palabra.length() ;i++){
            if((palabra.charAt(i)=='0') || (palabra.charAt(i)=='1')||
                (palabra.charAt(i)=='2') || (palabra.charAt(i)=='3')||
                    (palabra.charAt(i)=='4') || (palabra.charAt(i)=='5')||
                    (palabra.charAt(i)=='6') || (palabra.charAt(i)=='7')||
                    (palabra.charAt(i)=='8') || (palabra.charAt(i)=='9')){
                digitos++;
            }
        }
        for(int i=0; i<palabra.length(); i++){
            consonante++;
        }
        for(int i=0; i<palabra.length() ;i++){
            if((palabra.charAt(i)=='a') || (palabra.charAt(i)=='A')||
                (palabra.charAt(i)=='e') || (palabra.charAt(i)=='E')||
                    (palabra.charAt(i)=='i') || (palabra.charAt(i)=='I')||
                    (palabra.charAt(i)=='o') || (palabra.charAt(i)=='O')||
                    (palabra.charAt(i)=='u') || (palabra.charAt(i)=='U')){
                vocal++;
            }
        }
        
        totalconsonante=consonante-vocal-digitos;
        System.out.println("La palabra "+palabra+" contiene "+vocal+" Vocales");
        System.out.println("La palabra "+palabra+" contiene "+totalconsonante+" Consonantes");
        System.out.println("La palabra "+palabra+" contiene "+digitos+" Digitos");
    }
    
}
