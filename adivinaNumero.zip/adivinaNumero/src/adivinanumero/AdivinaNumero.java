/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package adivinanumero;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author rdominguez
 */
public class AdivinaNumero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random r = new Random();
		int adivinar = r.nextInt(100); // genera un número entre 0 y 99
		int i = 0; // crea variable contador que es usada para contar los intentos fallidos
		int apuesta = input("Adivina el número secreto entre 0 y 99. ¿Que número es?");
		while (adivinar != apuesta) { // si el número dado es distinto al sorteado repite
			i++; // incrementa variable contador
			if (adivinar > apuesta) {
				apuesta = input("El número a adivinar es más grande. \n Intentelo otra vez");
			} else {
				apuesta = input("El número a adivinar es más chico. \n Intentelo otra vez");
			}
		}
		JOptionPane.showMessageDialog(null,
				"Felicitaciones ha dado con el número con " + i + " intentos fallidos");
	}
	private static int input(String text) {
		return Integer.parseInt(JOptionPane.showInputDialog(text));
    }
    
}
