/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones;

/**
 *
 * @author rdominguez
 */
public class Libros extends Publicacion{
     //atributos
    private String ISBN;
    private String edicion;
    private String autor;
    //metodos
    public Libros(String titulo, float precio, int numpag, String ISBN,String edicion,String autor){
        super(titulo,precio,numpag);
        this.ISBN = ISBN;
        this.edicion = edicion;
        this.autor = autor;
          
    }
    public String Isbn(){
    return ISBN;
    }
    public String Edicion(){
    return edicion;
    }
    public String Autor(){
    return autor;
    }
    @Override
    public String toString()
    {
        return super.toString() +" Idenficador: " +ISBN+" Edicion: " +edicion+" Autor: " +autor;
    }
}
