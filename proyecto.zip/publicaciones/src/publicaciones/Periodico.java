/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones;

/**
 *
 * @author rdominguez
 */
public class Periodico extends Publicacion{
    private String secciones;
    private String editor;
    private String periodicidad;
    
     public Periodico(String titulo, float precio, int numpag,String secciones, String editor, String periodicidad){
         super(titulo,precio,numpag);
        this.secciones=secciones;
        this.editor=editor;
        this.periodicidad=periodicidad;
    }
    /**
     * Retorna valires
     */
    public String secciones(){
        return secciones;
    }
    public String editor(){
        return editor;
    }
    public String periodicidad(){
        return periodicidad;
    }
    
    @Override
    public String toString(){
          return super.toString()+ " Secciones: "+secciones+" Editor: "+editor+" Periodicidad: "+periodicidad;
    }
}
