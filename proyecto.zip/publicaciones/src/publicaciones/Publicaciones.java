/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package publicaciones;

import java.util.Scanner;

/**
 *
 * @author rdominguez
 */
public class Publicaciones {
     public static boolean isNumeric(String cadena){
        //valida que sea un numero
        cadena = cadena.trim();
        try{
            Integer.parseInt(cadena);
            return true;
        }
        catch(NumberFormatException nf)
        {
            return false;
        }
    }
     public static int menu(){
        //Menu de calculadora
        String ent="";
        Scanner entrada = new Scanner(System.in);
        int opc=0;
        System.out.println("Publicaciones");
        System.out.println("1.- PUBLICACION");
        System.out.println("2.- LIBRO");
        System.out.println("3.- REVISTA");
        System.out.println("4.- PERIODICO");
        System.out.println("5.- Salir");
        System.out.println("ELIGE UNA OPCION: ");
        do{
            ent = entrada.nextLine();
        }while(!isNumeric(ent));
        opc = Integer.parseInt(ent);
        return opc;
    }
     
    public static void main(String[] args) {
        // TODO code application logic here
        int opc=0;
        do{
            opc = menu();
            switch(opc)
            {
                case 1: 
                    Publicacion objpublicacion = new Publicacion("EL CIELO",18,20);
                    System.out.println(objpublicacion.toString());
                    break;
                case 2:
                    Libros objlibros = new Libros("LOS POBRES",15,40,"ISBN 7849","XXL","Ricado Dimas");
                    System.out.println(objlibros.toString());
                    break;
                case 3:
                    Revista objrevista = new Revista("TV NOTAS",18,20,"ISSN 7849",203,2022);
                    System.out.println(objrevista.toString());
                    break;
                case 4:
                    Periodico objperiodico = new Periodico("El informador",100,40,"Deportes,Espectaculos,Noticias","Juan Perez","Semanal");
                    System.out.println(objperiodico.toString());
                    break;
                //PONER LOS CASE DE LAS DEMAS MULTIPLICACIONES
                default: 
                    System.out.println("Opcion no programada");
            }
        }while(opc!=5);
    }
    
}
