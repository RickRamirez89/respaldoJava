/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones;

/**
 *
 * @author rdominguez
 */
public class Revista extends Publicacion{
    private String ISSN;
    private int numero;
    private int anio;
    
     public Revista(String titulo, float precio, int numpag,String ISSN, int numero, int anio){
         super(titulo,precio,numpag);
        this.ISSN=ISSN;
        this.numero=numero;
        this.anio=anio;
    }
    /**
     * Retorna valires
     */
    public String ISSN(){
        return ISSN;
    }
    public int numero(){
        return numero;
    }
    public int anio(){
        return anio;
    }
    
    @Override
    public String toString(){
          return super.toString()+ " Serial Revista: "+ISSN+" Numero: "+numero+" Anio: "+anio;
    }
    
}
