/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones;

/**
 *
 * @author rdominguez
 */
public class Publicacion {
    private String titulo;
    private float precio;
    private int numpag;
    /**
     * Constructor
     */
    public Publicacion(String titulo, float precio, int numpag){
        this.titulo=titulo;
        this.precio=precio;
        this.numpag=numpag;
    }
    /**
     * Retorna valires
     */
    public String titulo(){
        return titulo;
    }
    public float precio(){
        return precio;
    }
    public int numpag(){
        return numpag;
    }
    
    @Override
    public String toString(){
        return "Publicacion -> Titulo: "+titulo+" precio: "+precio+" numero paginas: "+numpag;
    }
}
