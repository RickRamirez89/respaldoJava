/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package anagrama;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author rdominguez
 */
public class Anagrama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s1="";
        String s2="";
        
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digita cadena 1: ");
           s1 =entrada.nextLine();
        System.out.println("Digita cadena 2: ");
           s2 =entrada.nextLine();
           
        if(s1.length() != s2.length()){
            System.out.println("No es un anagrama y la longitud es distinta");
        }
        else{
            char[] c1= s1.toCharArray();
            char[] c2= s2.toCharArray();
            
            Arrays.sort(c1);
            Arrays.sort(c2);
            
        if(Arrays.equals(c1, c2)){
            System.out.println("Es un anagrama");
        }
        else{
            System.out.println("No es un anagrama");
        }
        }
           
    }
    
}
