/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

/**
 *
 * @author rdominguez
 */
public class Metodos {
    
   private String cadena;
   private double resultado;
   private boolean suma;
   private boolean resta;
   private boolean multiplicacion;
   private boolean division;
  
   public Metodos(){
   
       cadena="";
       suma=false;
       resta=false;
       multiplicacion=false;
       division=false;
   }
   
   public String concatenamiento(String cadena){
   
       this.cadena=this.cadena+cadena;
       return this.cadena;
   }
   
   public void suma(String cadena){
   
       this.resultado=Double.parseDouble(cadena);
       suma=true;
       this.cadena="";
   }
   
    public void resta(String cadena){
   
       this.resultado=Double.parseDouble(cadena);
       resta=true;
       this.cadena="";   
   }
    
     public void multiplicacion(String cadena){
   
       this.resultado=Double.parseDouble(cadena);
       multiplicacion=true;
       this.cadena="";  
   }
     
      public void division(String cadena){
   
       this.resultado=Double.parseDouble(cadena);
       division=true;
       this.cadena="";  
   }
      
/////////////////// IMPRIME RESULTADOS ///////////////////////////////////
               
   public double resultado(String numero){
   
       if(suma==true){
           
       resultado=resultado+Double.parseDouble(numero);
       }
       
       else if(resta==true){
           
       resultado=resultado-Double.parseDouble(numero);  
       }
       
           else if(multiplicacion==true){
           
       resultado=resultado*Double.parseDouble(numero);   
       }
       
           else if(division==true){
           
       resultado=resultado/Double.parseDouble(numero);   
       }
 
       suma=false;
       resta=false;
       multiplicacion=false;
       division=false;
        
       return resultado;   
   }
                  
}
