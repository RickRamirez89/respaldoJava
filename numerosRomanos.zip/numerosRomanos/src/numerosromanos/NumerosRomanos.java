/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numerosromanos;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author rdominguez
 */
public class NumerosRomanos {

    /**
     * @param args the command line arguments
     */ 
    
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner entrada = new Scanner(System.in);
         
         String numeroR;
         char numero;
         String subCadena;
         int I=1,V=5,X=10,L=50,C=100,D=500,M=1000,suma=0,cont=0,total=0,cont2=0;
         
         ArrayList listado = new ArrayList();
         
         System.out.println("Ingresa numero romano: ");
         numeroR=entrada.nextLine().toUpperCase();
         subCadena=numeroR;
         total = numeroR.length();
         String []arreglo = new String[total];
         
         for(int i=0;i<arreglo.length;i++){
            numero=subCadena.charAt(cont);
            String charToString = String.valueOf(numero);
             //numero = subCadena.substring(cont);
             //System.out.println(charToString);
             arreglo[i]=charToString;
             cont++;
         }
         if(arreglo.length <= 10){
         for(int i=0;i<arreglo.length;i++){
             switch(arreglo[cont2]){
                 case "I":
                     listado.add(I);
                     break;
                     case "V":
                     listado.add(V);
                     break;
                     case "X":
                     listado.add(X);
                     break;
                     case "L":
                     listado.add(L);
                     break;
                     case "C":
                     listado.add(C);
                     break;
                     case "D":
                     listado.add(D);
                     break;
                     case "M":
                     listado.add(M);
                     break;
                 default:
             }
             cont2++;
         }
         for(int i=0;i<listado.size();i++){
                suma+=Double.parseDouble(listado.get(i).toString());
            }
         
         System.out.println("Fomato de numero romano "+numeroR+" en numearacion arabiga equivale a: "+suma);
         //System.out.println(listado);
	}
         else{
              System.out.println("El numero romano no puede tener mas de 10 caracteres.");
              //System.out.println(listado.size());
         }
      }
    }

