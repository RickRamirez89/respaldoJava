/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numerosprimos;

/**
 *
 * @author rdominguez
 */
public class NumerosPrimos {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        NumerosEnteros objNumerosEnteros = new NumerosEnteros();//método constructor
        objNumerosEnteros.pedirDatos();
        objNumerosEnteros.Primos();
    }
    
}
