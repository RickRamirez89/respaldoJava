/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numerosprimos;

import java.util.Scanner;

/**
 *
 * @author rdominguez
 */
public class NumerosEnteros {
    //@param
    int total =10;
    private int[] arr;
    Scanner entrada;
    
    public void pedirDatos(){
       Scanner entrada = new Scanner(System.in);
       arr = new int[total];
   
      System.out.println("Digita 10 numeros enteros.");
       for(int i=0; i<total; i++){
           System.out.println("Numero "+(i+1)+": ");
           arr[i] =entrada.nextInt();
       }
       System.out.println("Los numeros ingresados son:");
       for(int i=0; i<total; i++){
           System.out.print(arr[i]+", ");
       }  
    }
    public void Primos(){
       boolean bandera;
       int a=0;
       System.out.println("\n");
       for(int i=0; i<arr.length; i++)//i=0
       {
          int div=0;
          for(int j=1;j<=arr[i];j++){//j=1
            if(arr[i]%j==0){
              div++;//div=1
            }
          }
       if(div==2){
                System.out.println("El numero: "+arr[i]+" es primo");
        }
        else{
                System.out.println("El numero: "+arr[i]+" NO es primo");
        }
       }
       //System.out.println("\nTotal "+total); 
    }
}
